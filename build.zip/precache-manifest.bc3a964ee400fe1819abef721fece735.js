self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d727923340eb6a0cff078f9add0c977a",
    "url": "/covid/index.html"
  },
  {
    "revision": "6699946d7ca53359ef8b",
    "url": "/covid/static/css/main.9379b5ea.chunk.css"
  },
  {
    "revision": "e6c6d5dcfb4f1d3c8838",
    "url": "/covid/static/js/2.b70ea608.chunk.js"
  },
  {
    "revision": "23ec6c7f0411a6141095a6c739b32980",
    "url": "/covid/static/js/2.b70ea608.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6699946d7ca53359ef8b",
    "url": "/covid/static/js/main.2bbbdc88.chunk.js"
  },
  {
    "revision": "c50f865c2f338802ec08",
    "url": "/covid/static/js/runtime-main.678fe9b6.js"
  },
  {
    "revision": "86e07a427ace533c1beb57e795394ba8",
    "url": "/covid/static/media/archia-bold-webfont.86e07a42.eot"
  },
  {
    "revision": "9bc3d64094d3c3e27199eb7fdd7a9458",
    "url": "/covid/static/media/archia-bold-webfont.9bc3d640.ttf"
  },
  {
    "revision": "a22268c87e9381908593324346bb2fc9",
    "url": "/covid/static/media/archia-bold-webfont.a22268c8.woff"
  },
  {
    "revision": "ad8463d1313fed60e1d10324511efdc3",
    "url": "/covid/static/media/archia-bold-webfont.ad8463d1.woff2"
  },
  {
    "revision": "119d7372da448bff53152e6fd7842eb1",
    "url": "/covid/static/media/archia-light-webfont.119d7372.woff"
  },
  {
    "revision": "a1a88c4682805c801f7de93a09e9a537",
    "url": "/covid/static/media/archia-light-webfont.a1a88c46.ttf"
  },
  {
    "revision": "bd903ad6a9dc20fb3ae0be1d4db6ce7c",
    "url": "/covid/static/media/archia-light-webfont.bd903ad6.eot"
  },
  {
    "revision": "e1f0cf91c3c19dc35580d13ad3e01aa7",
    "url": "/covid/static/media/archia-light-webfont.e1f0cf91.woff2"
  },
  {
    "revision": "0a3767d818f1a64043d36d0f953b4ef2",
    "url": "/covid/static/media/archia-medium-webfont.0a3767d8.ttf"
  },
  {
    "revision": "80da55a565ba8976b8e9e84e8c511bf7",
    "url": "/covid/static/media/archia-medium-webfont.80da55a5.woff2"
  },
  {
    "revision": "93462af30f211b0fbb6a503c45623e22",
    "url": "/covid/static/media/archia-medium-webfont.93462af3.eot"
  },
  {
    "revision": "b325c0d36020370d075be09da1630b44",
    "url": "/covid/static/media/archia-medium-webfont.b325c0d3.woff"
  },
  {
    "revision": "02155d96e4a3f18305ab944925389c77",
    "url": "/covid/static/media/archia-regular-webfont.02155d96.woff2"
  },
  {
    "revision": "44b223ad896c78b16682dcf37a6bb6af",
    "url": "/covid/static/media/archia-regular-webfont.44b223ad.ttf"
  },
  {
    "revision": "571e46710904236b3eb8a4212d62d49d",
    "url": "/covid/static/media/archia-regular-webfont.571e4671.woff"
  },
  {
    "revision": "e0d9eab3c75035d714a61243b4bdc069",
    "url": "/covid/static/media/archia-regular-webfont.e0d9eab3.eot"
  },
  {
    "revision": "21351f93eacf73978ddf83e10929b449",
    "url": "/covid/static/media/archia-semibold-webfont.21351f93.woff"
  },
  {
    "revision": "6f45094ffba539a17d999dd65e661b80",
    "url": "/covid/static/media/archia-semibold-webfont.6f45094f.ttf"
  },
  {
    "revision": "890ee929da47c4931933ff77fd557520",
    "url": "/covid/static/media/archia-semibold-webfont.890ee929.woff2"
  },
  {
    "revision": "90c5d8485aebb0fae4d0e8a9f722088f",
    "url": "/covid/static/media/archia-semibold-webfont.90c5d848.eot"
  },
  {
    "revision": "0345166e4199c60cb4953236dbe08a9f",
    "url": "/covid/static/media/archia-thin-webfont.0345166e.woff"
  },
  {
    "revision": "47f5c030c96f1eeaba2576757bad7209",
    "url": "/covid/static/media/archia-thin-webfont.47f5c030.eot"
  },
  {
    "revision": "9a733c1c930c166cdae7a06adf29b930",
    "url": "/covid/static/media/archia-thin-webfont.9a733c1c.ttf"
  },
  {
    "revision": "e88f1cf30180bd74b3201844b0c03c69",
    "url": "/covid/static/media/archia-thin-webfont.e88f1cf3.woff2"
  }
]);